from io import BytesIO
from uuid import uuid4
from typing import Optional
import re
from collections import Counter

import fitz
import requests
from bs4 import BeautifulSoup
from docx import Document as DocxDocument
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="AnnotaRAG API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True, allow_methods=["*"], allow_headers=["*"],
)
guidelines = []

class WebpageRequest(BaseModel):
    url: str
    modality: Optional[str] = "General"

def extract_text(filename: str, content: bytes) -> str:
    name = filename.lower()
    try:
        if name.endswith(".pdf"):
            with fitz.open(stream=content, filetype="pdf") as pdf:
                return "\n".join(page.get_text() for page in pdf).strip()
        if name.endswith(".docx"):
            doc = DocxDocument(BytesIO(content))
            return "\n".join(p.text for p in doc.paragraphs).strip()
        if name.endswith(".txt"):
            return content.decode("utf-8", errors="replace").strip()
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Could not read file: {exc}") from exc
    raise HTTPException(status_code=400, detail="Supported formats: PDF, DOCX, TXT.")

@app.get("/")
def root():
    return {"message": "AnnotaRAG API is running", "docs": "/docs"}

@app.get("/api/health")
def health():
    return {"status": "healthy"}

@app.get("/api/guidelines")
def get_guidelines():
    return {"guidelines": guidelines, "count": len(guidelines)}

@app.post("/api/upload")
async def upload_guideline(file: UploadFile = File(...), modality: str = Form("General")):
    filename = file.filename or "uploaded-file"
    if not filename.lower().endswith((".pdf", ".docx", ".txt")):
        raise HTTPException(status_code=400, detail="Upload a PDF, DOCX, or TXT file.")
    content = await file.read()
    if len(content) > 10 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="File exceeds 10 MB.")
    text = extract_text(filename, content)
    if not text:
        raise HTTPException(status_code=400, detail="No readable text found in the file.")
    if modality == "Auto-detect":
        low = filename.lower()
        modality = next((m.title() for m in ("audio", "text", "image", "video", "lidar") if m in low), "General")
    record = {"id": str(uuid4()), "title": filename, "source_type": "Uploaded file",
              "source": filename, "modality": modality, "text": text, "preview": text[:320]}
    guidelines.insert(0, record)
    return {"message": "Guideline uploaded successfully", "guideline": record}

@app.post("/api/webpage")
def add_webpage(request: WebpageRequest):
    url = request.url.strip()
    if not url.startswith(("http://", "https://")):
        raise HTTPException(status_code=400, detail="Enter a complete http:// or https:// URL.")
    try:
        response = requests.get(url, timeout=15, headers={"User-Agent": "AnnotaRAG/1.0"})
        response.raise_for_status()
    except requests.RequestException as exc:
        raise HTTPException(status_code=400, detail=f"Could not fetch webpage: {exc}") from exc
    soup = BeautifulSoup(response.text, "html.parser")
    for tag in soup(["script", "style", "nav", "footer", "header", "noscript"]):
        tag.decompose()
    title = soup.title.get_text(" ", strip=True) if soup.title else url
    text = soup.get_text(" ", strip=True)
    if not text:
        raise HTTPException(status_code=400, detail="No readable text found on webpage.")
    record = {"id": str(uuid4()), "title": title[:180], "source_type": "Public webpage",
              "source": url, "modality": request.modality or "General",
              "text": text, "preview": text[:320]}
    guidelines.insert(0, record)
    return {"message": "Webpage added successfully", "guideline": record}

@app.delete("/api/guidelines/{guideline_id}")
def delete_guideline(guideline_id: str):
    for i, record in enumerate(guidelines):
        if record["id"] == guideline_id:
            return {"message": "Guideline deleted", "guideline": guidelines.pop(i)}
    raise HTTPException(status_code=404, detail="Guideline not found")


class AskRequest(BaseModel):
    question: str
    modality: Optional[str] = "All modalities"


def words(text: str):
    return re.findall(r"[a-zA-Z0-9]+", (text or "").lower())

def retrieve_context(question: str, modality: str = "All modalities", limit: int = 5):
    query_words = [w for w in words(question) if len(w) > 2]
    if not query_words:
        return []
    query_counts = Counter(query_words)
    matches = []
    for item in guidelines:
        item_mode = (item.get("modality") or "General").lower()
        if modality and modality.lower() not in ("all modalities", "all") and item_mode != modality.lower():
            continue
        text = item.get("text", "") or ""
        # Score paragraph-sized chunks, keeping their source title for citations.
        chunks = re.split(r"(?<=[.!?])\s+|\n+", text)
        current = ""
        for part in chunks:
            part = part.strip()
            if not part:
                continue
            if len(current) + len(part) < 900:
                current = (current + " " + part).strip()
            else:
                if current:
                    _score_chunk(current, query_counts, item, matches)
                current = part
        if current:
            _score_chunk(current, query_counts, item, matches)
    matches.sort(key=lambda x: x["score"], reverse=True)
    # Remove repeated chunks and retain only chunks with at least one query term.
    unique, result = set(), []
    for match in matches:
        key = (match["title"], match["text"][:180])
        if match["score"] > 0 and key not in unique:
            unique.add(key); result.append(match)
        if len(result) >= limit:
            break
    return result

def _score_chunk(chunk, query_counts, item, matches):
    counts = Counter(words(chunk))
    score = sum(min(counts[word], 3) * weight for word, weight in query_counts.items())
    if score:
        matches.append({"score": score, "text": chunk[:1400], "title": item.get("title", "Guideline"),
                        "source": item.get("source", item.get("title", "Guideline")),
                        "modality": item.get("modality", "General")})

@app.get("/api/ollama-health")
def ollama_health():
    try:
        response = requests.get("http://127.0.0.1:11434/api/tags", timeout=3)
        response.raise_for_status()
        data = response.json()
        return {"status": "connected", "models": [m.get("name") for m in data.get("models", [])]}
    except requests.RequestException:
        return {"status": "unavailable", "models": []}

@app.post("/api/ask")
def ask_question(request: AskRequest):
    question = request.question.strip()
    if not question:
        raise HTTPException(status_code=400, detail="Type a question first.")
    if not guidelines:
        raise HTTPException(status_code=400, detail="Upload a guideline or add a webpage first. Guidelines are stored in memory, so re-add them after restarting the backend.")
    context_items = retrieve_context(question, request.modality or "All modalities")
    if not context_items:
        return {"answer": "I couldn't find a relevant passage in the guidelines currently loaded. Try another wording or choose All modalities.", "sources": [], "model": "none"}
    context = "\n\n".join([f"SOURCE: {item['title']} | Modality: {item['modality']}\nPASSAGE: {item['text']}" for item in context_items])
    prompt = (
        "You are AnnotaRAG, an assistant for data annotation guidelines. Answer the user's question using ONLY the source passages below. "
        "Be clear and concise. If the passages do not contain the answer, say the guidelines do not specify it. Do not invent rules. "
        "Mention relevant source titles in your answer when helpful.\n\n"
        f"SOURCE PASSAGES:\n{context}\n\nQUESTION: {question}\nANSWER:"
    )
    model = "llama3.2:3b"
    try:
        response = requests.post("http://127.0.0.1:11434/api/generate", json={"model": model, "prompt": prompt, "stream": False, "options": {"temperature": 0.2}}, timeout=180)
        if response.status_code == 404:
            raise HTTPException(status_code=503, detail=f"Ollama could not find model '{model}'. In Command Prompt run: ollama pull {model}")
        response.raise_for_status()
        answer = (response.json().get("response") or "").strip()
        if not answer:
            raise HTTPException(status_code=502, detail="Ollama returned an empty answer. Try asking again.")
    except HTTPException:
        raise
    except requests.ConnectionError as exc:
        raise HTTPException(status_code=503, detail="Ollama is not running. Open Ollama and make sure the model llama3.2:3b is installed.") from exc
    except requests.Timeout as exc:
        raise HTTPException(status_code=504, detail="Ollama took too long to answer. Try a shorter question or a smaller model.") from exc
    except requests.RequestException as exc:
        raise HTTPException(status_code=502, detail=f"Ollama request failed: {exc}") from exc
    sources = []
    seen = set()
    for item in context_items:
        if item["title"] not in seen:
            sources.append({"title": item["title"], "source": item["source"], "modality": item["modality"], "excerpt": item["text"][:260]})
            seen.add(item["title"])
    return {"answer": answer, "sources": sources, "model": model}
