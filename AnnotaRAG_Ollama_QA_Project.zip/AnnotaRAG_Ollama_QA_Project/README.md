# AnnotaRAG — React + FastAPI + Ollama (local RAG starter)

## What this version does
- Upload PDF, DOCX, and TXT annotation guidelines.
- Import readable text from public webpages.
- Search and filter the guideline library by Audio, Text, Image, Video, and LiDAR.
- Ask questions in the dashboard. The backend retrieves relevant text passages and asks a local Ollama model to answer using those passages. Answers show the source passages selected for context.

## One-time requirements
1. Install Python 3.10+ and Node.js 18+.
2. Install Ollama for Windows from https://ollama.com/download.
3. Open Command Prompt (Windows + R, type `cmd`, press Enter) and download the model: `ollama pull llama3.2:3b`. This model download needs internet and several GB of disk space. After it is downloaded, answering can run locally/offline.
4. Confirm Ollama responds by running `ollama list`. You should see `llama3.2:3b`. Ollama normally runs as a background app on `http://127.0.0.1:11434`.

## Start the backend (Windows, Command Prompt)
Open Command Prompt with Windows + R → `cmd` → Enter, then run these commands one at a time:

```cmd
cd C:\Users\sindh\Downloads\AnnotaRAG_Complete_Project\backend
python -m venv venv
venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
uvicorn main:app --reload
```

If you already created `venv`, do not recreate it; run `venv\Scripts\activate.bat` and continue with package installation if needed. Keep this window open. Backend: http://127.0.0.1:8000. Health: http://127.0.0.1:8000/api/health. API docs: http://127.0.0.1:8000/docs.

## Start the frontend
Open a SECOND Command Prompt window and run:

```cmd
cd C:\Users\sindh\Downloads\AnnotaRAG_Complete_Project\frontend
npm install
npm run dev
```

Open the local URL printed by Vite, usually http://localhost:5173. Keep both terminal windows open, and keep Ollama running.

## How to ask a question
1. Add one or more guideline PDFs/DOCX/TXT files or readable webpages in the dashboard.
2. Scroll to **Ask your guidelines**.
3. Type your question, choose a modality or All modalities, and click **Ask AnnotaRAG**.
4. Read the answer and review the source passages listed below it.

## Troubleshooting
- **Ollama is not running:** open the Ollama app, then retry.
- **Model not found:** in Command Prompt run `ollama pull llama3.2:3b`.
- **No relevant passages:** upload the guideline that contains the answer or try different keywords / All modalities.
- **No guidelines loaded:** the starter stores uploaded records in backend memory; if you stop/restart the backend, upload/import them again.
- **Webpage cannot be added:** some websites block automated requests.
- **PowerShell says scripts are disabled:** use Command Prompt and `venv\Scripts\activate.bat` instead of PowerShell activation.

## Notes
This is a learning starter, not production-ready. Retrieval is lightweight keyword matching, not embedding-based semantic search. Ollama's model runs locally; first-time model download needs internet. Uploaded guideline text is held in backend memory and is lost when the backend restarts. Do not expose this development server to the public internet without adding persistence, authentication, access controls, and security hardening.
