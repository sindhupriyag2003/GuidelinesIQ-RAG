import { useEffect, useMemo, useRef, useState } from 'react';

const API = 'http://127.0.0.1:8000';
const MODES = ['All modalities', 'Audio', 'Text', 'Image', 'Video', 'LiDAR', 'General'];
const glyph = {Audio:'◖))', Text:'Tt', Image:'▧', Video:'▷', LiDAR:'⌁', General:'▤'};

export default function App() {
  const [health, setHealth] = useState('Checking');
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('All modalities');
  const [file, setFile] = useState(null);
  const [modality, setModality] = useState('Auto-detect');
  const [url, setUrl] = useState('');
  const [webMode, setWebMode] = useState('General');
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [answerSources, setAnswerSources] = useState([]);
  const [askBusy, setAskBusy] = useState(false);
  const [askError, setAskError] = useState('');
  const [askMode, setAskMode] = useState('All modalities');
  const fileRef = useRef(null);

  async function refresh() {
    try {
      const [h, r] = await Promise.all([fetch(API+'/api/health'), fetch(API+'/api/guidelines')]);
      if (!h.ok || !r.ok) throw new Error();
      const hd = await h.json(), d = await r.json();
      setHealth(hd.status === 'healthy' ? 'Connected' : 'Unavailable');
      setItems(Array.isArray(d) ? d : (d.guidelines || d.documents || []));
    } catch { setHealth('Offline'); }
  }
  useEffect(() => { refresh(); }, []);

  async function upload(e) {
    e.preventDefault(); setError(''); setNotice('');
    if (!file) { setError('Choose a PDF, DOCX, or TXT file first.'); return; }
    const body = new FormData(); body.append('file', file); body.append('modality', modality);
    setBusy(true);
    try {
      const r = await fetch(API+'/api/upload', {method:'POST', body});
      const d = await r.json(); if (!r.ok) throw new Error(d.detail || 'Upload failed');
      setNotice(d.message || 'Upload successful'); setFile(null); if(fileRef.current) fileRef.current.value='';
      await refresh();
    } catch (e) { setError(e.message || 'Could not connect to the backend.'); }
    finally { setBusy(false); }
  }
  async function addWeb(e) {
    e.preventDefault(); setError(''); setNotice('');
    if (!url.trim()) { setError('Enter a public webpage URL.'); return; }
    setBusy(true);
    try {
      const r = await fetch(API+'/api/webpage', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({url:url.trim(),modality:webMode})});
      const d = await r.json(); if (!r.ok) throw new Error(d.detail || 'Could not add webpage');
      setNotice(d.message || 'Webpage added'); setUrl(''); await refresh();
    } catch (e) { setError(e.message || 'Could not connect to the backend.'); }
    finally { setBusy(false); }
  }
  async function askQuestion(e) {
    e.preventDefault(); setAskError(''); setAnswer(''); setAnswerSources([]);
    if (!question.trim()) { setAskError('Type a question first.'); return; }
    setAskBusy(true);
    try {
      const r = await fetch(API+'/api/ask', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({question:question.trim(), modality:askMode})});
      const d = await r.json(); if (!r.ok) throw new Error(d.detail || 'Could not get an answer');
      setAnswer(d.answer || 'No answer returned.'); setAnswerSources(d.sources || []);
    } catch (e) { setAskError(e.message || 'Could not connect to AnnotaRAG.'); }
    finally { setAskBusy(false); }
  }
  async function remove(id) {
    try {
      const r = await fetch(API+'/api/guidelines/'+encodeURIComponent(id), {method:'DELETE'});
      const d = await r.json(); if (!r.ok) throw new Error(d.detail || 'Delete failed');
      setNotice('Guideline removed'); await refresh();
    } catch(e) { setError(e.message || 'Could not delete guideline.'); }
  }
  const shown = useMemo(() => items.filter(x => {
    const mode = (x.modality || 'General').toLowerCase();
    const hay = [x.title,x.source,x.preview,x.text].join(' ').toLowerCase();
    return (filter === 'All modalities' || mode === filter.toLowerCase()) && hay.includes(search.toLowerCase());
  }), [items, filter, search]);
  const count = mode => items.filter(x => (x.modality || 'General').toLowerCase() === mode.toLowerCase()).length;

  return <div className="app">
    <aside className="sidebar">
      <div className="brand"><div className="logo">A</div><div><b>AnnotaRAG</b><small>Annotation knowledge hub</small></div></div>
      <p className="nav-label">WORKSPACE</p><div className="nav-active">▤ &nbsp; Knowledge Base</div>
      <div className="side-note"><span className={health==='Connected'?'dot online':'dot'}></span><div><b>{health==='Connected'?'Backend connected':`Backend ${health.toLowerCase()}`}</b><small>Local development</small></div></div>
    </aside>
    <main className="main">
      <header className="topbar"><span>Workspace <i>/</i> <b>Knowledge Base</b></span><span className={'status '+(health==='Connected'?'good':'')}>● &nbsp;{health}</span></header>
      <section className="content">
        <p className="eyebrow">GUIDELINE LIBRARY</p><div className="title-row"><div><h1>Knowledge Base</h1><p className="subtitle">Collect, organize, and find annotation guidelines in one place.</p></div><span className="total">{items.length} documents</span></div>
        {notice && <div className="notice success">{notice}<button onClick={()=>setNotice('')}>×</button></div>}
        {error && <div className="notice error">{error}<button onClick={()=>setError('')}>×</button></div>}
        <div className="stats">
          <Stat name="Total guidelines" value={items.length} note="All sources" icon="▤"/>
          <Stat name="Audio" value={count('Audio')} note="Speech and sound" icon="◖))"/>
          <Stat name="Image + Video" value={count('Image')+count('Video')} note="Visual annotation" icon="▧"/>
          <Stat name="LiDAR" value={count('LiDAR')} note="3D point clouds" icon="⌁"/>
        </div>
        <section className="ask-panel">
          <div className="ask-heading"><div><span className="ask-kicker">LOCAL AI · RAG</span><h2>Ask your guidelines</h2><p className="muted">Ask a question and get an answer grounded in your uploaded sources using Ollama on your computer.</p></div><span className="local-badge">● Local model</span></div>
          <form onSubmit={askQuestion}>
            <label htmlFor="ask-question">Your question</label>
            <textarea id="ask-question" className="ask-input" rows="3" value={question} onChange={e=>setQuestion(e.target.value)} placeholder="Example: What should I do when a word in the audio is unclear?" />
            <div className="ask-controls"><select aria-label="Filter question by modality" value={askMode} onChange={e=>setAskMode(e.target.value)}>{MODES.map(m=><option key={m}>{m}</option>)}</select><button className="primary ask-button" disabled={askBusy}>{askBusy?'Finding answer…':'Ask AnnotaRAG →'}</button></div>
          </form>
          {askError && <div className="notice error ask-message">{askError}</div>}
          {answer && <div className="answer-card"><h3>Answer</h3><p className="answer-text">{answer}</p><div className="source-list"><b>Sources used</b>{answerSources.length ? answerSources.map((source,i)=><div className="source-item" key={source.title+i}><strong>{source.title}</strong><small>{source.modality} · {source.source}</small><p>{source.excerpt}{source.excerpt?.length>=260?'…':''}</p></div>) : <p className="muted">No matching source passages were found.</p>}</div></div>}
          <p className="ask-footnote">Your documents and questions are sent to the Ollama model running locally. Keep Ollama and the backend running.</p>
        </section>
        <div className="forms">
          <form className="panel" onSubmit={upload}><div className="panel-icon">↑</div><h2>Upload guidelines</h2><p className="muted">Add documents from your computer.</p>
            <label>Guideline file</label><div className="filebox" onClick={()=>fileRef.current?.click()}><strong>{file?file.name:'Choose a file to upload'}</strong><small>PDF, DOCX or TXT · Max 10 MB</small><input ref={fileRef} type="file" accept=".pdf,.docx,.txt" hidden onChange={e=>setFile(e.target.files?.[0]||null)}/></div>
            <label>Modality</label><select value={modality} onChange={e=>setModality(e.target.value)}><option>Auto-detect</option>{MODES.slice(1).map(m=><option key={m}>{m}</option>)}</select>
            <button className="primary" disabled={busy}>{busy?'Processing…':'Upload guideline →'}</button>
          </form>
          <form className="panel" onSubmit={addWeb}><div className="panel-icon blue">↗</div><h2>Add a public webpage</h2><p className="muted">Import readable text from an accessible page.</p>
            <label>Webpage URL</label><input className="input" type="url" placeholder="https://example.com/guidelines" value={url} onChange={e=>setUrl(e.target.value)}/>
            <label>Modality</label><select value={webMode} onChange={e=>setWebMode(e.target.value)}>{MODES.slice(1).map(m=><option key={m}>{m}</option>)}</select>
            <small className="hint">Some websites block automated requests.</small><button className="secondary" disabled={busy}>{busy?'Fetching…':'Add webpage →'}</button>
          </form>
        </div>
        <div className="library-head"><div><h2>Guideline library</h2><p className="muted">Search and filter your collected sources.</p></div><button className="refresh" onClick={refresh} title="Refresh">↻</button></div>
        <div className="tools"><input className="input search" value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search guidelines, sources, or text…"/><select value={filter} onChange={e=>setFilter(e.target.value)}>{MODES.map(m=><option key={m}>{m}</option>)}</select></div>
        <div className="chips">{MODES.slice(1,6).map(m=><button className={filter===m?'chosen':''} key={m} onClick={()=>setFilter(filter===m?'All modalities':m)}>{glyph[m]} {m} <span>{count(m)}</span></button>)}</div>
        <div className="panel records">{shown.length?shown.map(item=><div className="record" key={item.id}><div className="record-icon">{glyph[item.modality]||'▤'}</div><div className="record-body"><b>{item.title||item.source||'Untitled guideline'}</b><small>{item.source_type||'Source'} · {item.modality||'General'}</small><p>{item.preview||item.text||'No preview available.'}</p></div><button className="delete" title="Delete" onClick={()=>remove(item.id)}>×</button></div>):<div className="empty"><div>▤</div><b>{items.length?'No matching guidelines':'Your library is ready'}</b><p>{items.length?'Try another search or modality filter.':'Upload a guideline or add a public webpage to get started.'}</p></div>}</div>
        <p className="footnote">Starter version · Records reset when the backend restarts.</p>
      </section>
    </main>
  </div>;
}
function Stat({name,value,note,icon}) { return <div className="stat"><div className="stat-top"><span>{name}</span><i>{icon}</i></div><strong>{value}</strong><small>{note}</small></div>; }
